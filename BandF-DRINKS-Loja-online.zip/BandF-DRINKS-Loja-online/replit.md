# B&F DRINKS — Loja online

Loja online responsiva da adega B&F DRINKS, preparada para catálogo, carrinho, entrega, checkout e gestão própria de produtos.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/bf-drinks-store/src/App.tsx` — rotas e experiência principal da loja.
- `artifacts/bf-drinks-store/src/index.css` — tokens visuais, tipografia e estilos responsivos.
- `artifacts/bf-drinks-store/src/pages/` — páginas da loja e da área de gestão.
- `artifacts/api-server/` — API compartilhada, ainda sem endpoints de domínio.
- `lib/api-spec/openapi.yaml` — contrato da API, mantendo apenas o health check nesta etapa.

## Architecture decisions

- A primeira entrega é frontend-first e usa estado local para validar a experiência antes do cadastro de produtos.
- O catálogo começa com estado vazio intencional; produtos reais não devem ser inventados ou semeados antes da aprovação da estrutura.
- A experiência foi pensada para venda direta, sem dependência de iFood, Keeta ou outro marketplace.
- O visual usa uma identidade de adega moderna: preto/grafite predominante, dourado nos destaques e DM Serif Display + Sora; não usar laranja na identidade.

## Product

- Página inicial com posicionamento e entrada para a seleção.
- Catálogo com busca e categorias, pronto para receber produtos.
- Carrinho e checkout com endereço, entrega e forma de pagamento estruturados.
- Área de gestão preparada para adicionar, editar e remover produtos e categorias.
- Próxima etapa: persistir catálogo, regras de entrega e pedidos com recursos gratuitos do Replit.

## User preferences

- O usuário quer começar somente com recursos gratuitos disponíveis no Replit.
- O usuário quer validar a estrutura visual antes de adicionar produtos.
- O negócio não deve depender de marketplaces.

## Gotchas

- O workflow web injeta `PORT` e `BASE_PATH`; não iniciar o Vite diretamente sem essas variáveis.
- Quando o contrato da API for ampliado, atualizar `lib/api-spec/openapi.yaml` e rodar codegen antes de usar os hooks no frontend.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
