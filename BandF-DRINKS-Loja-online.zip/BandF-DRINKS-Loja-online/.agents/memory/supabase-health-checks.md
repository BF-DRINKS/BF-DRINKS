---
name: Supabase client-side health checks
description: Safe connectivity checks for frontend Supabase clients when customer data must remain private.
---

The browser-side connectivity check must not query a personal-data table just to prove that Supabase is reachable. A `permission denied for table` response is an authorization failure for that table, not evidence that the project is offline. Keep anonymous access closed and use a provider health endpoint that returns no application records.

**Why:** Granting `SELECT` to `anon` on a customer table would make personal records accessible to anyone with the public frontend key.

**How to apply:** For a frontend-only connection indicator, call Supabase's health endpoint with the publishable/anon key and an abortable timeout. Use authenticated, server-side access with explicit RLS policies for any real customer-data operation.