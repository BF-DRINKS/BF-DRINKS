begin;

-- Migration não destrutiva para o esquema existente da B&F Drinks.
-- Esta migration deve ser executada pelo SQL Editor do Supabase.
-- Ela não cria tabelas, não remove colunas e não apaga linhas.

do $$
begin
  if to_regclass('public."Clientes"') is null then
    raise exception 'A tabela public."Clientes" não existe. Migration interrompida.';
  end if;

  if to_regclass('public."Pedidos"') is null then
    raise exception 'A tabela public."Pedidos" não existe. Migration interrompida.';
  end if;

  if not exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'Clientes'
      and column_name = 'Telefone'
      and data_type = 'text'
  ) then
    raise exception 'Clientes."Telefone" precisa existir como text. Migration interrompida.';
  end if;

  if not exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'Pedidos'
      and column_name = 'Cliente_id'
      and data_type = 'bigint'
  ) then
    raise exception 'Pedidos."Cliente_id" precisa existir como bigint. Migration interrompida.';
  end if;

  if not exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'Clientes'
      and column_name = 'id'
      and (
        is_identity = 'YES'
        or column_default like 'nextval(%'
      )
  ) then
    raise exception 'Clientes."id" precisa ter identity ou sequence para novos cadastros. Migration interrompida.';
  end if;

  if not exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'Pedidos'
      and column_name = 'id'
      and (
        is_identity = 'YES'
        or column_default like 'nextval(%'
      )
  ) then
    raise exception 'Pedidos."id" precisa ter identity ou sequence para novos pedidos. Migration interrompida.';
  end if;
end
$$;

alter table public."Clientes"
  add column if not exists "Quantidade_Pedidos" integer;

do $$
begin
  if not exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'Clientes'
      and column_name = 'Quantidade_Pedidos'
      and data_type = 'integer'
  ) then
    raise exception 'Clientes."Quantidade_Pedidos" precisa ser integer. Migration interrompida.';
  end if;
end
$$;

-- Reconstrói a contagem a partir de pedidos realmente registrados.
update public."Clientes" as c
set "Quantidade_Pedidos" = coalesce((
  select count(*)::integer
  from public."Pedidos" as p
  where p."Cliente_id" = c."id"
), 0);

alter table public."Clientes"
  alter column "Quantidade_Pedidos" set default 0,
  alter column "Quantidade_Pedidos" set not null;

alter table public."Pedidos"
  add column if not exists "Chave_Idempotencia" text;

do $$
begin
  if not exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'Pedidos'
      and column_name = 'Chave_Idempotencia'
      and data_type = 'text'
  ) then
    raise exception 'Pedidos."Chave_Idempotencia" precisa ser text. Migration interrompida.';
  end if;

  if exists (
    select 1
    from public."Clientes"
    group by nullif(regexp_replace(trim("Telefone"), '[^0-9]', '', 'g'), '')
    having nullif(regexp_replace(trim("Telefone"), '[^0-9]', '', 'g'), '') is not null
       and count(*) > 1
  ) then
    raise exception 'Existem telefones duplicados em Clientes após normalização. Resolva-os sem apagar dados e execute novamente.';
  end if;

  if exists (
    select 1
    from public."Pedidos"
    where "Cliente_id" is not null
      and "Numero_Pedido" is not null
    group by "Cliente_id", "Numero_Pedido"
    having count(*) > 1
  ) then
    raise exception 'Existem números de pedido duplicados para um cliente. Resolva-os sem apagar dados e execute novamente.';
  end if;

  if exists (
    select 1
    from public."Pedidos"
    where nullif(trim("Chave_Idempotencia"), '') is not null
    group by "Chave_Idempotencia"
    having count(*) > 1
  ) then
    raise exception 'Existem chaves de idempotência duplicadas em Pedidos. Resolva-as sem apagar dados e execute novamente.';
  end if;
end
$$;

create unique index if not exists "Clientes_Telefone_normalizado_key"
  on public."Clientes" (
    (nullif(regexp_replace(trim("Telefone"), '[^0-9]', '', 'g'), ''))
  );

create unique index if not exists "Pedidos_Cliente_Numero_Pedido_key"
  on public."Pedidos" ("Cliente_id", "Numero_Pedido")
  where "Cliente_id" is not null and "Numero_Pedido" is not null;

create unique index if not exists "Pedidos_Chave_Idempotencia_key"
  on public."Pedidos" ("Chave_Idempotencia")
  where nullif(trim("Chave_Idempotencia"), '') is not null;

create or replace function public.sincronizar_quantidade_pedidos()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  cliente_antigo bigint;
  cliente_novo bigint;
begin
  if tg_op in ('DELETE', 'UPDATE') then
    cliente_antigo := old."Cliente_id";
  end if;

  if tg_op in ('INSERT', 'UPDATE') then
    cliente_novo := new."Cliente_id";
  end if;

  if cliente_antigo is not null then
    update public."Clientes"
    set "Quantidade_Pedidos" = (
      select count(*)::integer
      from public."Pedidos"
      where "Cliente_id" = cliente_antigo
    )
    where "id" = cliente_antigo;
  end if;

  if cliente_novo is not null
     and cliente_novo is distinct from cliente_antigo then
    update public."Clientes"
    set "Quantidade_Pedidos" = (
      select count(*)::integer
      from public."Pedidos"
      where "Cliente_id" = cliente_novo
    )
    where "id" = cliente_novo;
  end if;

  if tg_op = 'DELETE' then
    return old;
  end if;

  return new;
end
$$;

drop trigger if exists "Pedidos_sincronizar_quantidade" on public."Pedidos";

create trigger "Pedidos_sincronizar_quantidade"
after insert or update of "Cliente_id" or delete
on public."Pedidos"
for each row
execute function public.sincronizar_quantidade_pedidos();

create or replace function public.registrar_pedido(
  p_chave_idempotencia text,
  p_nome text,
  p_telefone text,
  p_cep text,
  p_endereco text,
  p_numero_endereco text,
  p_bairro text,
  p_complemento text,
  p_entrega numeric
)
returns table (
  cliente_id bigint,
  pedido_id bigint,
  numero_pedido integer,
  quantidade_pedidos integer
)
language plpgsql
security definer
set search_path = public
as $$
declare
  telefone_normalizado text;
  cliente_existente bigint;
  pedido_existente record;
  proximo_numero integer;
  novo_pedido_id bigint;
begin
  p_chave_idempotencia := nullif(trim(p_chave_idempotencia), '');
  p_nome := nullif(trim(p_nome), '');
  p_telefone := nullif(trim(p_telefone), '');
  p_cep := nullif(trim(p_cep), '');
  p_endereco := nullif(trim(p_endereco), '');
  p_numero_endereco := nullif(trim(p_numero_endereco), '');
  p_bairro := nullif(trim(p_bairro), '');
  p_complemento := nullif(trim(p_complemento), '');
  telefone_normalizado := nullif(regexp_replace(coalesce(p_telefone, ''), '[^0-9]', '', 'g'), '');

  if p_chave_idempotencia is null then
    raise exception 'A chave de idempotência é obrigatória.';
  end if;

  if p_nome is null or telefone_normalizado is null or p_cep is null
     or p_endereco is null or p_numero_endereco is null or p_bairro is null then
    raise exception 'Nome, telefone e endereço completo são obrigatórios.';
  end if;

  if p_entrega is null or p_entrega < 0 then
    raise exception 'A taxa de entrega é inválida.';
  end if;

  -- Evita duas criações concorrentes para o mesmo telefone.
  perform pg_advisory_xact_lock(hashtextextended(telefone_normalizado, 0));

  select
    p."id",
    p."Cliente_id",
    p."Numero_Pedido"
  into pedido_existente
  from public."Pedidos" as p
  where p."Chave_Idempotencia" = p_chave_idempotencia
  limit 1;

  if found then
    return query
    select
      pedido_existente."Cliente_id",
      pedido_existente."id",
      pedido_existente."Numero_Pedido",
      c."Quantidade_Pedidos"
    from public."Clientes" as c
    where c."id" = pedido_existente."Cliente_id";
    return;
  end if;

  select c."id"
  into cliente_existente
  from public."Clientes" as c
  where nullif(regexp_replace(trim(c."Telefone"), '[^0-9]', '', 'g'), '')
        = telefone_normalizado
  for update;

  if cliente_existente is null then
    insert into public."Clientes" (
      "created_at",
      "Nome",
      "Telefone",
      "Cep",
      "Endereço",
      "Numero",
      "Bairro",
      "Complemento",
      "Quantidade_Pedidos"
    )
    values (
      now(),
      p_nome,
      telefone_normalizado,
      p_cep,
      p_endereco,
      p_numero_endereco,
      p_bairro,
      p_complemento,
      0
    )
    returning "id" into cliente_existente;
  else
    update public."Clientes"
    set
      "Nome" = p_nome,
      "Telefone" = telefone_normalizado,
      "Cep" = p_cep,
      "Endereço" = p_endereco,
      "Numero" = p_numero_endereco,
      "Bairro" = p_bairro,
      "Complemento" = p_complemento
    where "id" = cliente_existente;
  end if;

  select coalesce(max("Numero_Pedido"), 0)::integer + 1
  into proximo_numero
  from public."Pedidos"
  where "Cliente_id" = cliente_existente;

  insert into public."Pedidos" (
    "created_at",
    "Cliente_id",
    "Numero_Pedido",
    "Nome",
    "Telefone",
    "Cep",
    "Endereço",
    "Numero_Endereço",
    "Bairro",
    "Complemento",
    "Entrega",
    "Chave_Idempotencia"
  )
  values (
    now(),
    cliente_existente,
    proximo_numero,
    p_nome,
    telefone_normalizado,
    p_cep,
    p_endereco,
    p_numero_endereco,
    p_bairro,
    p_complemento,
    p_entrega,
    p_chave_idempotencia
  )
  returning "id" into novo_pedido_id;

  return query
  select
    cliente_existente,
    novo_pedido_id,
    proximo_numero,
    c."Quantidade_Pedidos"
  from public."Clientes" as c
  where c."id" = cliente_existente;
end
$$;

alter table public."Clientes" enable row level security;
alter table public."Pedidos" enable row level security;

-- Nenhuma leitura pública de dados pessoais.
revoke all on table public."Clientes" from public, anon, authenticated;
revoke all on table public."Pedidos" from public, anon, authenticated;

revoke all on function public.registrar_pedido(
  text, text, text, text, text, text, text, text, numeric
) from public, anon, authenticated;

grant execute on function public.registrar_pedido(
  text, text, text, text, text, text, text, text, numeric
) to service_role;

commit;