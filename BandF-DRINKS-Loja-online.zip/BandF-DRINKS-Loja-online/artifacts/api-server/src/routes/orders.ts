import { Router, type IRouter } from "express";
import { logger } from "../lib/logger";

const router: IRouter = Router();

type RegisterOrderBody = {
  idempotencyKey?: unknown;
  nome?: unknown;
  telefone?: unknown;
  cep?: unknown;
  endereco?: unknown;
  numero?: unknown;
  bairro?: unknown;
  complemento?: unknown;
  entrega?: unknown;
};

function textValue(value: unknown, maxLength: number): string | null {
  if (typeof value !== "string") {
    return null;
  }

  const valueTrimmed = value.trim();
  return valueTrimmed.length > 0 && valueTrimmed.length <= maxLength
    ? valueTrimmed
    : null;
}

router.post("/orders", async (req, res) => {
  const body = req.body as RegisterOrderBody;
  const idempotencyKey = textValue(body.idempotencyKey, 100);
  const nome = textValue(body.nome, 160);
  const telefone = textValue(body.telefone, 40);
  const cep = textValue(body.cep, 20);
  const endereco = textValue(body.endereco, 240);
  const numero = textValue(body.numero, 40);
  const bairro = textValue(body.bairro, 160);
  const complemento =
    body.complemento === null ||
    body.complemento === undefined ||
    body.complemento === ""
      ? null
      : textValue(body.complemento, 240);
  const entrega = body.entrega;

  if (
    !idempotencyKey ||
    !/^[a-zA-Z0-9_-]{16,100}$/.test(idempotencyKey) ||
    !nome ||
    !telefone ||
    !cep ||
    !endereco ||
    !numero ||
    !bairro ||
    (body.complemento !== null &&
      body.complemento !== undefined &&
      body.complemento !== "" &&
      !complemento) ||
    typeof entrega !== "number" ||
    !Number.isFinite(entrega) ||
    ![3, 5, 8].includes(entrega)
  ) {
    res.status(400).json({
      message: "Dados do pedido inválidos.",
    });
    return;
  }

  const supabaseUrl = (
    process.env.SUPABASE_URL ?? process.env.VITE_SUPABASE_URL
  )?.replace(/\/+$/, "");
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) {
    logger.error(
      {
        hasSupabaseUrl: Boolean(supabaseUrl),
        hasServiceRoleKey: Boolean(serviceRoleKey),
      },
      "Supabase server configuration is incomplete",
    );
    res.status(503).json({
      message: "O registro de pedidos ainda não está configurado no servidor.",
    });
    return;
  }

  try {
    const resposta = await fetch(
      `${supabaseUrl}/rest/v1/rpc/registrar_pedido`,
      {
        method: "POST",
        headers: {
          apikey: serviceRoleKey,
          Authorization: `Bearer ${serviceRoleKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          p_chave_idempotencia: idempotencyKey,
          p_nome: nome,
          p_telefone: telefone,
          p_cep: cep,
          p_endereco: endereco,
          p_numero_endereco: numero,
          p_bairro: bairro,
          p_complemento: complemento,
          p_entrega: entrega,
        }),
      },
    );

    const respostaTexto = await resposta.text();
    let dados: unknown = null;

    try {
      dados = respostaTexto ? JSON.parse(respostaTexto) : null;
    } catch {
      dados = null;
    }

    if (!resposta.ok) {
      const erro = dados as { code?: unknown; message?: unknown } | null;
      logger.error(
        {
          status: resposta.status,
          code: typeof erro?.code === "string" ? erro.code : undefined,
        },
        "Supabase rejected order registration",
      );
      res.status(502).json({
        message:
          "Não foi possível registrar o pedido. Confira se a migration do Supabase foi aplicada.",
      });
      return;
    }

    const registro = Array.isArray(dados) ? dados[0] : dados;
    const resultado = registro as {
      pedido_id?: unknown;
      numero_pedido?: unknown;
      quantidade_pedidos?: unknown;
    } | null;

    if (
      !resultado ||
      typeof resultado.pedido_id !== "number" ||
      typeof resultado.numero_pedido !== "number" ||
      typeof resultado.quantidade_pedidos !== "number"
    ) {
      logger.error("Supabase returned an unexpected order registration shape");
      res.status(502).json({
        message: "O servidor recebeu uma resposta inválida do Supabase.",
      });
      return;
    }

    res.status(201).json({
      pedidoId: resultado.pedido_id,
      numeroPedido: resultado.numero_pedido,
      quantidadePedidos: resultado.quantidade_pedidos,
    });
  } catch (erro) {
    logger.error({ err: erro }, "Order registration request failed");
    res.status(502).json({
      message: "Não foi possível conectar ao Supabase para registrar o pedido.",
    });
  }
});

export default router;